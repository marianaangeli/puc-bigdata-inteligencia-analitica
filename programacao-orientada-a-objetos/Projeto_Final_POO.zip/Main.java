// Main.java
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<Financiamento> lista = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        InterfaceUsuario.exibirMenu(lista, scanner);

        salvarSerializado(lista, "financiamentos.ser");
        salvarEmArquivoTexto(lista, "financiamentos.txt");

        System.out.println("\nArquivo de texto salvo:");
        lerArquivoTexto("financiamentos.txt");
    }

    public static void salvarSerializado(ArrayList<Financiamento> lista, String nomeArquivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nomeArquivo))) {
            oos.writeObject(lista);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void salvarEmArquivoTexto(ArrayList<Financiamento> lista, String nomeArquivo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(nomeArquivo))) {
            for (Financiamento f : lista) {
                writer.println(f.gerarLinhaTexto());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void lerArquivoTexto(String nomeArquivo) {
        try (BufferedReader reader = new BufferedReader(new FileReader(nomeArquivo))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                System.out.println(linha);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Financiamento> lerSerializado(String nomeArquivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nomeArquivo))) {
            return (ArrayList<Financiamento>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}
