public // AumentoMaiorDoQueJurosException.java
public class AumentoMaiorDoQueJurosException extends Exception {
    public AumentoMaiorDoQueJurosException(String mensagem) {
        super(mensagem);
    }
}

 Main {
    
}
