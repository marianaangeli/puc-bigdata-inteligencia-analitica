// InterfaceUsuario.java
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class InterfaceUsuario {
    public static void exibirMenu(ArrayList<Financiamento> lista, Scanner scanner) {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- MENU ---");
            System.out.println("1 - Cadastrar Casa");
            System.out.println("2 - Cadastrar Apartamento");
            System.out.println("3 - Cadastrar Terreno");
            System.out.println("4 - Listar financiamentos");
            System.out.println("0 - Sair e salvar");
            System.out.print("Escolha: ");
            try {
                opcao = scanner.nextInt();
                switch (opcao) {
                    case 1 -> cadastrarCasa(lista, scanner);
                    case 2 -> cadastrarApartamento(lista, scanner);
                    case 3 -> cadastrarTerreno(lista, scanner);
                    case 4 -> listar(lista);
                    case 0 -> System.out.println("Salvando e saindo...");
                    default -> System.out.println("Opção inválida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida! Digite um número inteiro.");
                scanner.nextLine(); // Limpa buffer
            }
        }
    }

    private static void cadastrarCasa(ArrayList<Financiamento> lista, Scanner s) {
        System.out.print("Valor do imóvel: ");
        double valor = s.nextDouble();
        System.out.print("Prazo (anos): ");
        int prazo = s.nextInt();
        System.out.print("Taxa de juros (%): ");
        double juros = s.nextDouble();
        System.out.print("Área construída: ");
        double construida = s.nextDouble();
        System.out.print("Área do terreno: ");
        double terreno = s.nextDouble();

        lista.add(new Casa(valor, prazo, juros, construida, terreno));
    }

    private static void cadastrarApartamento(ArrayList<Financiamento> lista, Scanner s) {
        System.out.print("Valor do imóvel: ");
        double valor = s.nextDouble();
        System.out.print("Prazo (anos): ");
        int prazo = s.nextInt();
        System.out.print("Taxa de juros (%): ");
        double juros = s.nextDouble();
        System.out.print("Número de quartos: ");
        int quartos = s.nextInt();
        System.out.print("Número de garagens: ");
        int garagens = s.nextInt();

        lista.add(new Apartamento(valor, prazo, juros, quartos, garagens));
    }

    private static void cadastrarTerreno(ArrayList<Financiamento> lista, Scanner s) {
        System.out.print("Valor do imóvel: ");
        double valor = s.nextDouble();
        System.out.print("Prazo (anos): ");
        int prazo = s.nextInt();
        System.out.print("Taxa de juros (%): ");
        double juros = s.nextDouble();
        System.out.print("Área do terreno: ");
        double area = s.nextDouble();

        lista.add(new Terreno(valor, prazo, juros, area));
    }

    private static void listar(ArrayList<Financiamento> lista) {
        System.out.println("\n--- FINANCIAMENTOS ---");
        for (Financiamento f : lista) {
            System.out.println(f);
            System.out.printf("Prestação mensal: R$%.2f\n", f.calcularPrestacao());
        }
    }
}
