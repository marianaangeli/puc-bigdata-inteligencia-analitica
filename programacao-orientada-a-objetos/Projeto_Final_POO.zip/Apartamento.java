// Apartamento.java
public class Apartamento extends Financiamento {
    private static final long serialVersionUID = 1L;
    private int numeroQuartos;
    private int numeroGaragens;

    public Apartamento(double valorImovel, int prazoAnos, double taxaJurosAnual,
                       int numeroQuartos, int numeroGaragens) {
        super(valorImovel, prazoAnos, taxaJurosAnual);
        this.numeroQuartos = numeroQuartos;
        this.numeroGaragens = numeroGaragens;
    }

    @Override
    public double calcularPrestacao() {
        double fator = 1 + getTaxaJurosAnual() / 100;
        return getValorImovel() * fator / (getPrazoAnos() * 12);
    }

    @Override
    public String toString() {
        return super.toString() + ", Quartos: " + numeroQuartos + ", Garagens: " + numeroGaragens;
    }
}