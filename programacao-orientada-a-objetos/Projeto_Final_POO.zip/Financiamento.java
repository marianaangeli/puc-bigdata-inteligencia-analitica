// Financiamento.java
import java.io.Serializable;

public abstract class Financiamento implements Serializable {
    private static final long serialVersionUID = 1L;

    private double valorImovel;
    private int prazoAnos;
    private double taxaJurosAnual;

    public Financiamento(double valorImovel, int prazoAnos, double taxaJurosAnual) {
        this.valorImovel = valorImovel;
        this.prazoAnos = prazoAnos;
        this.taxaJurosAnual = taxaJurosAnual;
    }

    public abstract double calcularPrestacao();

    public String gerarLinhaTexto() {
        return this.getClass().getSimpleName() + ";" + valorImovel + ";" + prazoAnos + ";" + taxaJurosAnual;
    }

    public double getValorImovel() {
        return valorImovel;
    }

    public int getPrazoAnos() {
        return prazoAnos;
    }

    public double getTaxaJurosAnual() {
        return taxaJurosAnual;
    }

    @Override
    public String toString() {
        return "Valor do imóvel: R$" + valorImovel +
                ", Prazo: " + prazoAnos + " anos" +
                ", Juros Anual: " + taxaJurosAnual + "%";
    }
}