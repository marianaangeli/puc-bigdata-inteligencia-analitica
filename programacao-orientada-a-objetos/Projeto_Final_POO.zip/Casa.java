// Casa.java
public class Casa extends Financiamento {
    private static final long serialVersionUID = 1L;
    private static final double SEGURO_MENSAL = 80.0;

    private double areaConstruida;
    private double areaTerreno;

    public Casa(double valorImovel, int prazoAnos, double taxaJurosAnual,
                double areaConstruida, double areaTerreno) {
        super(valorImovel, prazoAnos, taxaJurosAnual);
        this.areaConstruida = areaConstruida;
        this.areaTerreno = areaTerreno;
    }

    @Override
    public double calcularPrestacao() {
        double prestacaoBase = getValorImovel() * (1 + getTaxaJurosAnual() / 100);
        return prestacaoBase / (getPrazoAnos() * 12) + SEGURO_MENSAL;
    }

    @Override
    public String toString() {
        return super.toString() + ", Área construída: " + areaConstruida + "m², Área do terreno: " + areaTerreno + "m²";
    }
}
