// Terreno.java
public class Terreno extends Financiamento {
    private static final long serialVersionUID = 1L;
    private double areaTotal;

    public Terreno(double valorImovel, int prazoAnos, double taxaJurosAnual, double areaTotal) {
        super(valorImovel, prazoAnos, taxaJurosAnual);
        this.areaTotal = areaTotal;
    }

    @Override
    public double calcularPrestacao() {
        return getValorImovel() * (1 + getTaxaJurosAnual() / 100) / (getPrazoAnos() * 12);
    }

    @Override
    public String toString() {
        return super.toString() + ", Área do terreno: " + areaTotal + "m²";
    }
}